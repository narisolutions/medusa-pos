"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BASE_SALES_CHANNEL_PRODUCT_FIELDS = exports.BASE_PRODUCT_FIELDS = void 0;
exports.resolveProductFields = resolveProductFields;
exports.resolveSalesChannelProductFields = resolveSalesChannelProductFields;
exports.BASE_PRODUCT_FIELDS = [
    "*",
    "images.*",
    "categories.id",
    "categories.name",
    "categories.handle",
    "categories.parent_category.id",
    "categories.parent_category.name",
    "categories.parent_category.handle",
    "tags.id",
    "tags.value",
    "collection.id",
    "collection.title",
    "collection.handle",
    "options.id",
    "options.title",
    "options.values.*",
    "variants.*",
    "variants.options.id",
    "variants.options.value",
    "variants.options.option.id",
    "variants.options.option.title",
    "variants.prices.*",
    "variants.calculated_price.*",
    "variants.images.*",
];
exports.BASE_SALES_CHANNEL_PRODUCT_FIELDS = [
    "products_link.product.*",
    "products_link.product.images.*",
    "products_link.product.categories.id",
    "products_link.product.categories.name",
    "products_link.product.categories.handle",
    "products_link.product.categories.parent_category.id",
    "products_link.product.categories.parent_category.name",
    "products_link.product.categories.parent_category.handle",
    "products_link.product.tags.id",
    "products_link.product.tags.value",
    "products_link.product.options.id",
    "products_link.product.options.title",
    "products_link.product.options.values.*",
    "products_link.product.variants.*",
    "products_link.product.variants.options.id",
    "products_link.product.variants.options.value",
    "products_link.product.variants.options.option.id",
    "products_link.product.variants.options.option.title",
    "products_link.product.variants.prices.*",
    "products_link.product.variants.calculated_price.*",
    "products_link.product.variants.images.*",
    "products_link.product.variants.inventory_items.*",
    "products_link.product.variants.inventory_items.inventory.*",
];
function resolveProductFields(customFields) {
    const fields = [...exports.BASE_PRODUCT_FIELDS];
    for (const f of customFields) {
        const trimmed = f.trim();
        if (trimmed && !fields.includes(trimmed)) {
            fields.push(trimmed);
        }
    }
    return fields;
}
function resolveSalesChannelProductFields(customFields) {
    const fields = [...exports.BASE_SALES_CHANNEL_PRODUCT_FIELDS];
    for (const f of customFields) {
        const trimmed = f.trim();
        if (!trimmed)
            continue;
        const prefixed = `products_link.product.${trimmed}`;
        if (!fields.includes(prefixed)) {
            fields.push(prefixed);
        }
    }
    return fields;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvZHVjdC1maWVsZHMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvdXRpbHMvcHJvZHVjdC1maWVsZHMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBcURBLG9EQVNDO0FBRUQsNEVBV0M7QUEzRVksUUFBQSxtQkFBbUIsR0FBRztJQUNqQyxHQUFHO0lBQ0gsVUFBVTtJQUNWLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsbUJBQW1CO0lBQ25CLCtCQUErQjtJQUMvQixpQ0FBaUM7SUFDakMsbUNBQW1DO0lBQ25DLFNBQVM7SUFDVCxZQUFZO0lBQ1osZUFBZTtJQUNmLGtCQUFrQjtJQUNsQixtQkFBbUI7SUFDbkIsWUFBWTtJQUNaLGVBQWU7SUFDZixrQkFBa0I7SUFDbEIsWUFBWTtJQUNaLHFCQUFxQjtJQUNyQix3QkFBd0I7SUFDeEIsNEJBQTRCO0lBQzVCLCtCQUErQjtJQUMvQixtQkFBbUI7SUFDbkIsNkJBQTZCO0lBQzdCLG1CQUFtQjtDQUNwQixDQUFBO0FBRVksUUFBQSxpQ0FBaUMsR0FBRztJQUMvQyx5QkFBeUI7SUFDekIsZ0NBQWdDO0lBQ2hDLHFDQUFxQztJQUNyQyx1Q0FBdUM7SUFDdkMseUNBQXlDO0lBQ3pDLHFEQUFxRDtJQUNyRCx1REFBdUQ7SUFDdkQseURBQXlEO0lBQ3pELCtCQUErQjtJQUMvQixrQ0FBa0M7SUFDbEMsa0NBQWtDO0lBQ2xDLHFDQUFxQztJQUNyQyx3Q0FBd0M7SUFDeEMsa0NBQWtDO0lBQ2xDLDJDQUEyQztJQUMzQyw4Q0FBOEM7SUFDOUMsa0RBQWtEO0lBQ2xELHFEQUFxRDtJQUNyRCx5Q0FBeUM7SUFDekMsbURBQW1EO0lBQ25ELHlDQUF5QztJQUN6QyxrREFBa0Q7SUFDbEQsNERBQTREO0NBQzdELENBQUE7QUFFRCxTQUFnQixvQkFBb0IsQ0FBQyxZQUFzQjtJQUN6RCxNQUFNLE1BQU0sR0FBRyxDQUFDLEdBQUcsMkJBQW1CLENBQUMsQ0FBQTtJQUN2QyxLQUFLLE1BQU0sQ0FBQyxJQUFJLFlBQVksRUFBRSxDQUFDO1FBQzdCLE1BQU0sT0FBTyxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQTtRQUN4QixJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztZQUN6QyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFBO1FBQ3RCLENBQUM7SUFDSCxDQUFDO0lBQ0QsT0FBTyxNQUFNLENBQUE7QUFDZixDQUFDO0FBRUQsU0FBZ0IsZ0NBQWdDLENBQUMsWUFBc0I7SUFDckUsTUFBTSxNQUFNLEdBQUcsQ0FBQyxHQUFHLHlDQUFpQyxDQUFDLENBQUE7SUFDckQsS0FBSyxNQUFNLENBQUMsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQUM3QixNQUFNLE9BQU8sR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUE7UUFDeEIsSUFBSSxDQUFDLE9BQU87WUFBRSxTQUFRO1FBQ3RCLE1BQU0sUUFBUSxHQUFHLHlCQUF5QixPQUFPLEVBQUUsQ0FBQTtRQUNuRCxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDO1lBQy9CLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUE7UUFDdkIsQ0FBQztJQUNILENBQUM7SUFDRCxPQUFPLE1BQU0sQ0FBQTtBQUNmLENBQUMifQ==
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parsePosQueryParams = parsePosQueryParams;
function parsePosQueryParams(req) {
    const currency_code = typeof req.query.currency_code === "string" && req.query.currency_code
        ? req.query.currency_code
        : undefined;
    const custom_fields = typeof req.query.custom_fields === "string" && req.query.custom_fields
        ? req.query.custom_fields.split(",").map((f) => f.trim()).filter(Boolean)
        : [];
    return { currency_code, custom_fields };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicXVlcnktcGFyYW1zLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3V0aWxzL3F1ZXJ5LXBhcmFtcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUVBLGtEQVlDO0FBWkQsU0FBZ0IsbUJBQW1CLENBQUMsR0FBWTtJQUM5QyxNQUFNLGFBQWEsR0FDakIsT0FBTyxHQUFHLENBQUMsS0FBSyxDQUFDLGFBQWEsS0FBSyxRQUFRLElBQUksR0FBRyxDQUFDLEtBQUssQ0FBQyxhQUFhO1FBQ3BFLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLGFBQWE7UUFDekIsQ0FBQyxDQUFDLFNBQVMsQ0FBQTtJQUVmLE1BQU0sYUFBYSxHQUNqQixPQUFPLEdBQUcsQ0FBQyxLQUFLLENBQUMsYUFBYSxLQUFLLFFBQVEsSUFBSSxHQUFHLENBQUMsS0FBSyxDQUFDLGFBQWE7UUFDcEUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7UUFDekUsQ0FBQyxDQUFDLEVBQUUsQ0FBQTtJQUVSLE9BQU8sRUFBRSxhQUFhLEVBQUUsYUFBYSxFQUFFLENBQUE7QUFDekMsQ0FBQyJ9
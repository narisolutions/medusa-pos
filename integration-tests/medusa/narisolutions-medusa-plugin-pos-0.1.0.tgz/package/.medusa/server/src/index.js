"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPluginOptions = getPluginOptions;
exports.default = PosPlugin;
let _options = {};
function getPluginOptions() {
    return _options;
}
function PosPlugin(options = {}) {
    _options = options;
    return {
        resolve: "@narisolutions/medusa-plugin-pos",
        options: options,
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFJQSw0Q0FFQztBQUVELDRCQU1DO0FBWkQsSUFBSSxRQUFRLEdBQXFCLEVBQUUsQ0FBQTtBQUVuQyxTQUFnQixnQkFBZ0I7SUFDOUIsT0FBTyxRQUFRLENBQUE7QUFDakIsQ0FBQztBQUVELFNBQXdCLFNBQVMsQ0FBQyxVQUE0QixFQUFFO0lBQzlELFFBQVEsR0FBRyxPQUFPLENBQUE7SUFDbEIsT0FBTztRQUNMLE9BQU8sRUFBRSxrQ0FBa0M7UUFDM0MsT0FBTyxFQUFFLE9BQWtDO0tBQzVDLENBQUE7QUFDSCxDQUFDIn0=
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = void 0;
const utils_1 = require("@medusajs/utils");
const product_fields_1 = require("../../../../../utils/product-fields");
const query_params_1 = require("../../../../../utils/query-params");
const index_1 = require("../../../../../index");
const GET = async (req, res) => {
    const { sales_channel_id, ean } = req.params;
    const { currency_code: qsCurrency, custom_fields } = (0, query_params_1.parsePosQueryParams)(req);
    const currency_code = qsCurrency ?? (0, index_1.getPluginOptions)().defaultCurrencyCode;
    const query = req.scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const { data: [byBarcode] } = await query.graph({
        entity: "product_variant",
        filters: { barcode: ean },
        fields: ["product_id"],
    });
    let variant = byBarcode;
    if (!variant?.product_id) {
        const { data: [byEan] } = await query.graph({
            entity: "product_variant",
            filters: { ean },
            fields: ["product_id"],
        });
        variant = byEan;
    }
    if (!variant?.product_id) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.NOT_FOUND, `Product with barcode ${ean} not found.`);
    }
    const fields = (0, product_fields_1.resolveProductFields)(custom_fields);
    const context = currency_code
        ? { variants: { calculated_price: (0, utils_1.QueryContext)({ currency_code }) } }
        : {};
    const { data: [product] } = await query.graph({
        entity: "product",
        filters: { id: variant.product_id },
        fields,
        context,
    }, { cache: { enable: true, autoInvalidate: true } });
    const variant_ids = (product?.variants ?? []).map((v) => v.id);
    const quantities = await (0, utils_1.getVariantAvailability)(query, { variant_ids, sales_channel_id });
    product?.variants?.forEach((v) => {
        v.inventory_quantity = quantities[v.id]?.availability ?? 0;
    });
    res.status(200).json(product);
};
exports.GET = GET;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3Bvcy9wcm9kdWN0LWJ5LWJhcmNvZGUvW3NhbGVzX2NoYW5uZWxfaWRdL1tlYW5dL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUNBLDJDQUt3QjtBQUd4QiwyREFBNkQ7QUFDN0QsdURBQTBEO0FBQzFELG1DQUEwQztBQUVuQyxNQUFNLEdBQUcsR0FBRyxLQUFLLEVBQUUsR0FBK0IsRUFBRSxHQUFtQixFQUFFLEVBQUU7SUFDaEYsTUFBTSxFQUFFLGdCQUFnQixFQUFFLEdBQUcsRUFBRSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUE7SUFDNUMsTUFBTSxFQUFFLGFBQWEsRUFBRSxVQUFVLEVBQUUsYUFBYSxFQUFFLEdBQUcsSUFBQSxrQ0FBbUIsRUFBQyxHQUFHLENBQUMsQ0FBQTtJQUM3RSxNQUFNLGFBQWEsR0FBRyxVQUFVLElBQUksSUFBQSx3QkFBZ0IsR0FBRSxDQUFDLG1CQUFtQixDQUFBO0lBQzFFLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGlDQUF5QixDQUFDLEtBQUssQ0FBQyxDQUFBO0lBRWhFLE1BQU0sRUFBRSxJQUFJLEVBQUUsQ0FBQyxTQUFTLENBQUMsRUFBRSxHQUFHLE1BQU0sS0FBSyxDQUFDLEtBQUssQ0FBQztRQUM5QyxNQUFNLEVBQUUsaUJBQWlCO1FBQ3pCLE9BQU8sRUFBRSxFQUFFLE9BQU8sRUFBRSxHQUFHLEVBQUU7UUFDekIsTUFBTSxFQUFFLENBQUMsWUFBWSxDQUFDO0tBQ3ZCLENBQUMsQ0FBQTtJQUNGLElBQUksT0FBTyxHQUFHLFNBQVMsQ0FBQTtJQUN2QixJQUFJLENBQUMsT0FBTyxFQUFFLFVBQVUsRUFBRSxDQUFDO1FBQ3pCLE1BQU0sRUFBRSxJQUFJLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBRSxHQUFHLE1BQU0sS0FBSyxDQUFDLEtBQUssQ0FBQztZQUMxQyxNQUFNLEVBQUUsaUJBQWlCO1lBQ3pCLE9BQU8sRUFBRSxFQUFFLEdBQUcsRUFBRTtZQUNoQixNQUFNLEVBQUUsQ0FBQyxZQUFZLENBQUM7U0FDdkIsQ0FBQyxDQUFBO1FBQ0YsT0FBTyxHQUFHLEtBQUssQ0FBQTtJQUNqQixDQUFDO0lBRUQsSUFBSSxDQUFDLE9BQU8sRUFBRSxVQUFVLEVBQUUsQ0FBQztRQUN6QixNQUFNLElBQUksbUJBQVcsQ0FDbkIsbUJBQVcsQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUMzQix3QkFBd0IsR0FBRyxhQUFhLENBQ3pDLENBQUE7SUFDSCxDQUFDO0lBRUQsTUFBTSxNQUFNLEdBQUcsSUFBQSxxQ0FBb0IsRUFBQyxhQUFhLENBQUMsQ0FBQTtJQUVsRCxNQUFNLE9BQU8sR0FBRyxhQUFhO1FBQzNCLENBQUMsQ0FBQyxFQUFFLFFBQVEsRUFBRSxFQUFFLGdCQUFnQixFQUFFLElBQUEsb0JBQVksRUFBQyxFQUFFLGFBQWEsRUFBRSxDQUFDLEVBQUUsRUFBRTtRQUNyRSxDQUFDLENBQUMsRUFBRSxDQUFBO0lBRU4sTUFBTSxFQUFFLElBQUksRUFBRSxDQUFDLE9BQU8sQ0FBQyxFQUFFLEdBQUcsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUMzQztRQUNFLE1BQU0sRUFBRSxTQUFTO1FBQ2pCLE9BQU8sRUFBRSxFQUFFLEVBQUUsRUFBRSxPQUFPLENBQUMsVUFBVSxFQUFFO1FBQ25DLE1BQU07UUFDTixPQUFPO0tBQ1IsRUFDRCxFQUFFLEtBQUssRUFBRSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxFQUFFLENBQ2xELENBQUE7SUFFRCxNQUFNLFdBQVcsR0FBRyxDQUFDLE9BQU8sRUFBRSxRQUFRLElBQUksRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBTSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUE7SUFDbkUsTUFBTSxVQUFVLEdBQUcsTUFBTSxJQUFBLDhCQUFzQixFQUFDLEtBQUssRUFBRSxFQUFFLFdBQVcsRUFBRSxnQkFBZ0IsRUFBRSxDQUFDLENBQUE7SUFFekYsT0FBTyxFQUFFLFFBQVEsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFNLEVBQUUsRUFBRTtRQUNwQyxDQUFDLENBQUMsa0JBQWtCLEdBQUcsVUFBVSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxZQUFZLElBQUksQ0FBQyxDQUFBO0lBQzVELENBQUMsQ0FBQyxDQUFBO0lBRUYsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUE7QUFDL0IsQ0FBQyxDQUFBO0FBcERZLFFBQUEsR0FBRyxPQW9EZiJ9
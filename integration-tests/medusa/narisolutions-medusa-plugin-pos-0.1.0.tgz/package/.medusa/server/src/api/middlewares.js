"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const framework_1 = require("@medusajs/framework");
const index_1 = require("../index");
class SimpleRateLimiter {
    constructor(windowMs, max) {
        this.windowMs = windowMs;
        this.max = max;
        this.store = new Map();
    }
    middleware() {
        return (req, res, next) => {
            const key = req.ip ?? "unknown";
            const now = Date.now();
            let entry = this.store.get(key);
            if (!entry || now > entry.resetAt) {
                entry = { count: 0, resetAt: now + this.windowMs };
                this.store.set(key, entry);
            }
            entry.count++;
            if (entry.count > this.max) {
                res.status(429).json({ message: "Too many requests" });
                return;
            }
            next();
        };
    }
}
let _limiterMiddleware = null;
let _limiterInitialized = false;
const posRateLimitMiddleware = (req, res, next) => {
    if (!_limiterInitialized) {
        _limiterInitialized = true;
        const opts = (0, index_1.getPluginOptions)().rateLimit;
        if (opts) {
            _limiterMiddleware = new SimpleRateLimiter(opts.windowMs, opts.max).middleware();
        }
    }
    if (_limiterMiddleware) {
        _limiterMiddleware(req, res, next);
    }
    else {
        next();
    }
};
const config = {
    routes: [
        {
            matcher: "/pos/*",
            middlewares: [(0, framework_1.authenticate)("user", ["bearer"]), posRateLimitMiddleware],
        },
    ],
};
exports.default = config;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWlkZGxld2FyZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvYXBpL21pZGRsZXdhcmVzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsbURBQTBFO0FBQzFFLG1DQUEwQztBQUUxQyxNQUFNLGlCQUFpQjtJQUdyQixZQUNtQixRQUFnQixFQUNoQixHQUFXO1FBRFgsYUFBUSxHQUFSLFFBQVEsQ0FBUTtRQUNoQixRQUFHLEdBQUgsR0FBRyxDQUFRO1FBSnRCLFVBQUssR0FBRyxJQUFJLEdBQUcsRUFBOEMsQ0FBQTtJQUtsRSxDQUFDO0lBRUosVUFBVTtRQUNSLE9BQU8sQ0FBQyxHQUFRLEVBQUUsR0FBUSxFQUFFLElBQVMsRUFBRSxFQUFFO1lBQ3ZDLE1BQU0sR0FBRyxHQUFJLEdBQUcsQ0FBQyxFQUFhLElBQUksU0FBUyxDQUFBO1lBQzNDLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQTtZQUN0QixJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQTtZQUUvQixJQUFJLENBQUMsS0FBSyxJQUFJLEdBQUcsR0FBRyxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUM7Z0JBQ2xDLEtBQUssR0FBRyxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsT0FBTyxFQUFFLEdBQUcsR0FBRyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUE7Z0JBQ2xELElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQTtZQUM1QixDQUFDO1lBRUQsS0FBSyxDQUFDLEtBQUssRUFBRSxDQUFBO1lBRWIsSUFBSSxLQUFLLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztnQkFDM0IsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPLEVBQUUsbUJBQW1CLEVBQUUsQ0FBQyxDQUFBO2dCQUN0RCxPQUFNO1lBQ1IsQ0FBQztZQUVELElBQUksRUFBRSxDQUFBO1FBQ1IsQ0FBQyxDQUFBO0lBQ0gsQ0FBQztDQUNGO0FBRUQsSUFBSSxrQkFBa0IsR0FBcUQsSUFBSSxDQUFBO0FBQy9FLElBQUksbUJBQW1CLEdBQUcsS0FBSyxDQUFBO0FBRS9CLE1BQU0sc0JBQXNCLEdBQUcsQ0FBQyxHQUFRLEVBQUUsR0FBUSxFQUFFLElBQVMsRUFBRSxFQUFFO0lBQy9ELElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1FBQ3pCLG1CQUFtQixHQUFHLElBQUksQ0FBQTtRQUMxQixNQUFNLElBQUksR0FBRyxJQUFBLHdCQUFnQixHQUFFLENBQUMsU0FBUyxDQUFBO1FBQ3pDLElBQUksSUFBSSxFQUFFLENBQUM7WUFDVCxrQkFBa0IsR0FBRyxJQUFJLGlCQUFpQixDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFVBQVUsRUFBRSxDQUFBO1FBQ2xGLENBQUM7SUFDSCxDQUFDO0lBRUQsSUFBSSxrQkFBa0IsRUFBRSxDQUFDO1FBQ3ZCLGtCQUFrQixDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUE7SUFDcEMsQ0FBQztTQUFNLENBQUM7UUFDTixJQUFJLEVBQUUsQ0FBQTtJQUNSLENBQUM7QUFDSCxDQUFDLENBQUE7QUFFRCxNQUFNLE1BQU0sR0FBc0I7SUFDaEMsTUFBTSxFQUFFO1FBQ047WUFDRSxPQUFPLEVBQUUsUUFBUTtZQUNqQixXQUFXLEVBQUUsQ0FBQyxJQUFBLHdCQUFZLEVBQUMsTUFBTSxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxzQkFBc0IsQ0FBQztTQUN4RTtLQUNGO0NBQ0YsQ0FBQTtBQUVELGtCQUFlLE1BQU0sQ0FBQSJ9
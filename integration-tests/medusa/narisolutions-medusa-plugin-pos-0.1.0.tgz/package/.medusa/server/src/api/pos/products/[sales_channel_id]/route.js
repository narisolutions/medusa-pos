"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = void 0;
const utils_1 = require("@medusajs/utils");
const product_fields_1 = require("../../../../utils/product-fields");
const query_params_1 = require("../../../../utils/query-params");
const index_1 = require("../../../../index");
const GET = async (req, res) => {
    const { sales_channel_id } = req.params;
    const { currency_code: qsCurrency, custom_fields } = (0, query_params_1.parsePosQueryParams)(req);
    const currency_code = qsCurrency ?? (0, index_1.getPluginOptions)().defaultCurrencyCode;
    const query = req.scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const fields = (0, product_fields_1.resolveSalesChannelProductFields)(custom_fields);
    const context = currency_code
        ? {
            products_link: {
                product: {
                    variants: {
                        calculated_price: (0, utils_1.QueryContext)({ currency_code }),
                    },
                },
            },
        }
        : {};
    const { data: [sales_channel] } = await query.graph({
        entity: "sales_channel",
        filters: { id: sales_channel_id },
        fields,
        context,
    }, { cache: { enable: true, autoInvalidate: true } });
    const products = sales_channel?.products_link
        ?.map((i) => i?.product)
        .filter((i) => i?.status === "published") ?? [];
    const variant_ids = products
        .map((p) => (p?.variants ?? []).map((v) => v.id))
        .flat();
    const quantities = await (0, utils_1.getVariantAvailability)(query, { variant_ids, sales_channel_id });
    products.forEach((p) => {
        p?.variants?.forEach((v) => {
            v.inventory_quantity = quantities[v.id]?.availability ?? 0;
        });
    });
    res.status(200).json(products);
};
exports.GET = GET;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3Bvcy9wcm9kdWN0cy9bc2FsZXNfY2hhbm5lbF9pZF0vcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQ0EsMkNBSXdCO0FBQ3hCLDJEQUF5RTtBQUN6RSx1REFBMEQ7QUFDMUQsbUNBQTBDO0FBRW5DLE1BQU0sR0FBRyxHQUFHLEtBQUssRUFBRSxHQUErQixFQUFFLEdBQW1CLEVBQUUsRUFBRTtJQUNoRixNQUFNLEVBQUUsZ0JBQWdCLEVBQUUsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFBO0lBQ3ZDLE1BQU0sRUFBRSxhQUFhLEVBQUUsVUFBVSxFQUFFLGFBQWEsRUFBRSxHQUFHLElBQUEsa0NBQW1CLEVBQUMsR0FBRyxDQUFDLENBQUE7SUFDN0UsTUFBTSxhQUFhLEdBQUcsVUFBVSxJQUFJLElBQUEsd0JBQWdCLEdBQUUsQ0FBQyxtQkFBbUIsQ0FBQTtJQUMxRSxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxpQ0FBeUIsQ0FBQyxLQUFLLENBQUMsQ0FBQTtJQUVoRSxNQUFNLE1BQU0sR0FBRyxJQUFBLGlEQUFnQyxFQUFDLGFBQWEsQ0FBQyxDQUFBO0lBRTlELE1BQU0sT0FBTyxHQUFHLGFBQWE7UUFDM0IsQ0FBQyxDQUFDO1lBQ0UsYUFBYSxFQUFFO2dCQUNiLE9BQU8sRUFBRTtvQkFDUCxRQUFRLEVBQUU7d0JBQ1IsZ0JBQWdCLEVBQUUsSUFBQSxvQkFBWSxFQUFDLEVBQUUsYUFBYSxFQUFFLENBQUM7cUJBQ2xEO2lCQUNGO2FBQ0Y7U0FDRjtRQUNILENBQUMsQ0FBQyxFQUFFLENBQUE7SUFFTixNQUFNLEVBQUUsSUFBSSxFQUFFLENBQUMsYUFBYSxDQUFDLEVBQUUsR0FBRyxNQUFNLEtBQUssQ0FBQyxLQUFLLENBQ2pEO1FBQ0UsTUFBTSxFQUFFLGVBQWU7UUFDdkIsT0FBTyxFQUFFLEVBQUUsRUFBRSxFQUFFLGdCQUFnQixFQUFFO1FBQ2pDLE1BQU07UUFDTixPQUFPO0tBQ1IsRUFDRCxFQUFFLEtBQUssRUFBRSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxFQUFFLENBQ2xELENBQUE7SUFFRCxNQUFNLFFBQVEsR0FDWixhQUFhLEVBQUUsYUFBYTtRQUMxQixFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQU0sRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQztTQUM1QixNQUFNLENBQUMsQ0FBQyxDQUFNLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBRSxNQUFNLEtBQUssV0FBVyxDQUFDLElBQUksRUFBRSxDQUFBO0lBRXhELE1BQU0sV0FBVyxHQUFHLFFBQVE7U0FDekIsR0FBRyxDQUFDLENBQUMsQ0FBTSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxRQUFRLElBQUksRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBTSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7U0FDMUQsSUFBSSxFQUFFLENBQUE7SUFFVCxNQUFNLFVBQVUsR0FBRyxNQUFNLElBQUEsOEJBQXNCLEVBQUMsS0FBSyxFQUFFLEVBQUUsV0FBVyxFQUFFLGdCQUFnQixFQUFFLENBQUMsQ0FBQTtJQUV6RixRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBTSxFQUFFLEVBQUU7UUFDMUIsQ0FBQyxFQUFFLFFBQVEsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFNLEVBQUUsRUFBRTtZQUM5QixDQUFDLENBQUMsa0JBQWtCLEdBQUcsVUFBVSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxZQUFZLElBQUksQ0FBQyxDQUFBO1FBQzVELENBQUMsQ0FBQyxDQUFBO0lBQ0osQ0FBQyxDQUFDLENBQUE7SUFFRixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQTtBQUNoQyxDQUFDLENBQUE7QUFoRFksUUFBQSxHQUFHLE9BZ0RmIn0=